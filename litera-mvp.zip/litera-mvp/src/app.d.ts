// Ambient SvelteKit types can be extended here.
declare global {
  namespace App {}
}
export {};
