export function plural(n: number, one: string, few: string, many: string): string {
  const lastTwo = n % 100;
  const last = n % 10;
  return lastTwo >= 11 && lastTwo <= 14 ? many : last === 1 ? one : last >= 2 && last <= 4 ? few : many;
}
export function dateRange(start: string, end: string): string {
  const make = (s: string) => new Date(`${s}T12:00:00.000Z`);
  const startDate = make(start), endDate = make(end);
  const d = (date: Date) => new Intl.DateTimeFormat('ru-RU', { day: 'numeric', timeZone: 'UTC' }).format(date);
  const dm = (date: Date) => new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'short', timeZone: 'UTC' }).format(date).replace('.', '');
  return startDate.getUTCMonth() === endDate.getUTCMonth() && startDate.getUTCFullYear() === endDate.getUTCFullYear()
    ? `${d(startDate)}–${dm(endDate)}` : `${dm(startDate)} – ${dm(endDate)}`;
}
export function percent(value: number, total: number): number {
  return total > 0 ? Math.round(value * 100 / total) : 0;
}
