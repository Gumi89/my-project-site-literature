export type BookStatus = 'not_started' | 'reading' | 'finished';
export type ChapterStatus = 'not_read' | 'read' | 'passed';
export type QuizKind = 'chapter' | 'final';
export interface Quote { text: string; attribution: string }
export interface ScheduleBook {
  id: number; slug: string; title: string; author: string; position: number;
  description: string; themes: string[]; startDate: string; endDate: string;
  sourceUrl: string; accent: string; chapterCount: number; readCount: number;
  passedCount: number; finalPassed: boolean; status: BookStatus;
}
export interface Chapter {
  id: number; bookId: number; position: number; title: string; sourceLabel: string;
  summary: string; characters: string[]; quotes: Quote[];
  readAt: string | null; testPassed: boolean; status: ChapterStatus;
}
export interface PublicQuestion { id: number; position: number; text: string; options: string[] }
export interface QuizFormState { message?: string; values?: Record<string, string> }
export interface Dashboard {
  totalBooks: number; finishedBooks: number; totalChapters: number; readChapters: number;
  averageScore: number | null; testsTaken: number;
  weakTopics: { topic: string; errors: number; answers: number; errorRate: number }[];
}
