import db, { LOCAL_USER_ID } from './db';
import type { QuizKind } from '$lib/types';

export const PASS_PERCENT = 70;
interface PrivateQuestion { id: number; options: string; correct_option: number }

type Result = { ok: true; attemptId: number } | { ok: false; message: string; values: Record<string, string> };

/** Validates exclusively against server-side questions and saves an attempt atomically. */
export function submitQuiz(bookId: number, kind: QuizKind, chapterId: number | null, form: FormData): Result {
  const questions = db.prepare(`SELECT id, options, correct_option FROM questions
    WHERE book_id = ? AND kind = ? AND chapter_id IS ? ORDER BY position`).all(bookId, kind, chapterId) as PrivateQuestion[];
  if (questions.length === 0) return { ok: false, message: 'В этом тесте пока нет вопросов.', values: {} };
  const values: Record<string, string> = {};
  const answers: { questionId: number; answer: number; isCorrect: number }[] = [];
  let invalid = false;
  for (const question of questions) {
    const entries = form.getAll(`q_${question.id}`);
    const value = entries.length === 1 && typeof entries[0] === 'string' ? entries[0] : '';
    values[String(question.id)] = value;
    const options = JSON.parse(question.options) as string[];
    if (!/^(0|[1-9]\d*)$/.test(value) || Number(value) >= options.length) {
      invalid = true;
      continue;
    }
    const answer = Number(value);
    answers.push({ questionId: question.id, answer, isCorrect: Number(answer === question.correct_option) });
  }
  if (invalid) return { ok: false, message: 'Ответьте на каждый вопрос, выбрав один из предложенных вариантов.', values };

  const correctCount = answers.reduce((sum, a) => sum + a.isCorrect, 0);
  const passed = Number(correctCount * 100 >= questions.length * PASS_PERCENT);
  const attemptId = db.transaction(() => {
    const row = db.prepare(`INSERT INTO test_attempts
      (user_id, book_id, chapter_id, kind, total_questions, correct_count, passed, attempted_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).run(LOCAL_USER_ID, bookId, chapterId, kind, questions.length,
        correctCount, passed, new Date().toISOString());
    const id = Number(row.lastInsertRowid);
    const insertAnswer = db.prepare('INSERT INTO test_answers (attempt_id, question_id, answer, is_correct) VALUES (?, ?, ?, ?)');
    for (const answer of answers) insertAnswer.run(id, answer.questionId, answer.answer, answer.isCorrect);
    // A later failed retry never cancels a previous pass.
    if (kind === 'chapter' && chapterId && passed) {
      db.prepare(`UPDATE user_progress SET test_passed = 1, test_passed_at = COALESCE(test_passed_at, ?)
        WHERE user_id = ? AND chapter_id = ?`).run(new Date().toISOString(), LOCAL_USER_ID, chapterId);
    }
    return id;
  })();
  return { ok: true, attemptId };
}
