import db, { LOCAL_USER_ID } from './db';
import type { Chapter, Dashboard, PublicQuestion, Quote, ScheduleBook, QuizKind } from '$lib/types';

interface BookRow {
  id: number; slug: string; title: string; author: string; position: number; description: string;
  themes: string; startDate: string; endDate: string; sourceUrl: string; accent: string;
  chapterCount: number; readCount: number; passedCount: number; finalPassed: number;
}
interface ChapterRow {
  id: number; bookId: number; position: number; title: string; sourceLabel: string; summary: string;
  characters: string; quotes: string; readAt: string | null; testPassed: number;
}
interface QuestionRow { id: number; position: number; text: string; options: string }

const bookQuery = `
  SELECT b.id, b.slug, b.title, b.author, b.position, b.description, b.themes,
         b.start_date AS startDate, b.end_date AS endDate, b.source_url AS sourceUrl, b.accent,
         COUNT(c.id) AS chapterCount,
         COUNT(p.chapter_id) AS readCount,
         COALESCE(SUM(CASE WHEN p.test_passed = 1 THEN 1 ELSE 0 END), 0) AS passedCount,
         EXISTS(SELECT 1 FROM test_attempts a
                WHERE a.user_id = @userId AND a.book_id = b.id AND a.kind = 'final' AND a.passed = 1) AS finalPassed
  FROM books b
  LEFT JOIN chapters c ON c.book_id = b.id
  LEFT JOIN user_progress p ON p.chapter_id = c.id AND p.user_id = @userId
  GROUP BY b.id ORDER BY b.position`;

export function getSchedule(): ScheduleBook[] {
  const rows = db.prepare(bookQuery).all({ userId: LOCAL_USER_ID }) as BookRow[];
  return rows.map((row) => ({
    ...row,
    themes: JSON.parse(row.themes) as string[],
    finalPassed: Boolean(row.finalPassed),
    status: row.finalPassed ? 'finished' : row.readCount ? 'reading' : 'not_started'
  }));
}
export function getBook(slug: string): ScheduleBook | undefined {
  return getSchedule().find((book) => book.slug === slug);
}
export function getChapters(bookId: number): Chapter[] {
  const rows = db.prepare(`
    SELECT c.id, c.book_id AS bookId, c.position, c.title, c.source_label AS sourceLabel,
           c.summary, c.characters, c.quotes, p.read_at AS readAt,
           COALESCE(p.test_passed, 0) AS testPassed
    FROM chapters c LEFT JOIN user_progress p ON p.chapter_id = c.id AND p.user_id = ?
    WHERE c.book_id = ? ORDER BY c.position`).all(LOCAL_USER_ID, bookId) as ChapterRow[];
  return rows.map((row) => ({
    ...row, characters: JSON.parse(row.characters) as string[], quotes: JSON.parse(row.quotes) as Quote[],
    testPassed: Boolean(row.testPassed), status: row.testPassed ? 'passed' : row.readAt ? 'read' : 'not_read'
  }));
}
export function getChapter(bookId: number, chapterId: string | number): Chapter | undefined {
  if (!/^\d+$/.test(String(chapterId))) return undefined;
  return getChapters(bookId).find((chapter) => chapter.id === Number(chapterId));
}

// Never include correct_option or explanation in the HTML before submission.
export function getPublicQuestions(bookId: number, kind: QuizKind, chapterId: number | null): PublicQuestion[] {
  const rows = db.prepare(`SELECT id, position, text, options FROM questions
    WHERE book_id = ? AND kind = ? AND chapter_id IS ? ORDER BY position`).all(bookId, kind, chapterId) as QuestionRow[];
  return rows.map((row) => ({ ...row, options: JSON.parse(row.options) as string[] }));
}

export function getDashboard(): Dashboard {
  const books = getSchedule();
  // Only the latest attempt of each test counts; all tests have equal weight.
  const summary = db.prepare(`
    WITH ranked AS (
      SELECT correct_count * 100.0 / total_questions AS percent,
             ROW_NUMBER() OVER (PARTITION BY book_id, kind, COALESCE(chapter_id, 0) ORDER BY id DESC) AS rn
      FROM test_attempts WHERE user_id = ?
    )
    SELECT ROUND(AVG(percent)) AS averageScore, COUNT(*) AS testsTaken FROM ranked WHERE rn = 1
  `).get(LOCAL_USER_ID) as { averageScore: number | null; testsTaken: number };
  const weakTopics = db.prepare(`
    WITH ranked AS (
      SELECT id, ROW_NUMBER() OVER (PARTITION BY book_id, kind, COALESCE(chapter_id, 0) ORDER BY id DESC) AS rn
      FROM test_attempts WHERE user_id = ?
    )
    SELECT q.topic, SUM(1 - ans.is_correct) AS errors, COUNT(*) AS answers,
           ROUND(100.0 * SUM(1 - ans.is_correct) / COUNT(*)) AS errorRate
    FROM ranked r JOIN test_answers ans ON ans.attempt_id = r.id
    JOIN questions q ON q.id = ans.question_id
    WHERE r.rn = 1
    GROUP BY q.topic HAVING SUM(1 - ans.is_correct) > 0
    ORDER BY errorRate DESC, errors DESC, q.topic LIMIT 5
  `).all(LOCAL_USER_ID) as Dashboard['weakTopics'];
  return {
    totalBooks: books.length,
    finishedBooks: books.filter((b) => b.finalPassed).length,
    totalChapters: books.reduce((sum, b) => sum + b.chapterCount, 0),
    readChapters: books.reduce((sum, b) => sum + b.readCount, 0),
    ...summary, weakTopics
  };
}

export function getAttempt(id: string) {
  if (!/^\d+$/.test(id)) return undefined;
  const attempt = db.prepare(`SELECT a.id, a.book_id AS bookId, a.chapter_id AS chapterId, a.kind,
      a.total_questions AS totalQuestions, a.correct_count AS correctCount, a.passed,
      a.attempted_at AS attemptedAt, b.title AS bookTitle, b.slug AS bookSlug,
      ch.source_label AS chapterLabel, ch.title AS chapterTitle
    FROM test_attempts a JOIN books b ON b.id = a.book_id
    LEFT JOIN chapters ch ON ch.id = a.chapter_id
    WHERE a.id = ? AND a.user_id = ?`).get(Number(id), LOCAL_USER_ID) as {
      id: number; bookId: number; chapterId: number | null; kind: QuizKind; totalQuestions: number;
      correctCount: number; passed: number; attemptedAt: string; bookTitle: string; bookSlug: string;
      chapterLabel: string | null; chapterTitle: string | null;
    } | undefined;
  if (!attempt) return undefined;
  const answers = db.prepare(`SELECT q.id, q.text, q.options, q.correct_option AS correctOption, q.explanation,
      q.topic, ans.answer, ans.is_correct AS isCorrect, ref.id AS referenceId,
      ref.source_label AS referenceLabel, ref.title AS referenceTitle
    FROM test_answers ans JOIN questions q ON q.id = ans.question_id
    JOIN chapters ref ON ref.id = q.reference_chapter_id
    WHERE ans.attempt_id = ? ORDER BY q.position`).all(attempt.id) as {
      id: number; text: string; options: string; correctOption: number; explanation: string; topic: string;
      answer: number; isCorrect: number; referenceId: number; referenceLabel: string; referenceTitle: string;
    }[];
  return { ...attempt, passed: Boolean(attempt.passed), score: Math.round(attempt.correctCount * 100 / attempt.totalQuestions),
    answers: answers.map((answer) => ({ ...answer, isCorrect: Boolean(answer.isCorrect), options: JSON.parse(answer.options) as string[] })) };
}
