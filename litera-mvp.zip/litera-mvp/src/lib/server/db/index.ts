import Database from 'better-sqlite3';
import { building } from '$app/environment';
import schema from './schema.sql?raw';
import { seedBooks } from '../content/books';

export const LOCAL_USER_ID = 1;
// SvelteKit imports server modules while building; never create/seed a real DB then.
const db = new Database(building ? ':memory:' : (process.env.DATABASE_PATH || 'app.db'));
db.pragma('foreign_keys = ON');
db.pragma('journal_mode = WAL');
db.pragma('busy_timeout = 5000');
db.exec(schema);

// A single local user is deliberate. This is NOT authentication.
db.prepare('INSERT OR IGNORE INTO users (id, name) VALUES (?, ?)').run(LOCAL_USER_ID, 'Читатель');

function moscowToday(): string {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Moscow', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(new Date());
  const get = (key: string) => parts.find((p) => p.type === key)?.value ?? '';
  return `${get('year')}-${get('month')}-${get('day')}`;
}
function addDays(date: string, amount: number): string {
  const day = new Date(`${date}T00:00:00.000Z`);
  day.setUTCDate(day.getUTCDate() + amount);
  return day.toISOString().slice(0, 10);
}

// No overwrite of existing books/progress. Demo plan begins on the first launch.
const seed = db.transaction(() => {
  const count = db.prepare('SELECT COUNT(*) AS n FROM books').get() as { n: number };
  if (count.n !== 0) return;
  const start = moscowToday();
  const bookInsert = db.prepare(`INSERT INTO books
    (slug, title, author, position, description, themes, start_date, end_date, source_url, accent)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
  const chapterInsert = db.prepare(`INSERT INTO chapters
    (book_id, position, title, source_label, summary, characters, quotes) VALUES (?, ?, ?, ?, ?, ?, ?)`);
  const questionInsert = db.prepare(`INSERT INTO questions
    (book_id, chapter_id, reference_chapter_id, kind, position, text, options, correct_option, explanation, topic)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);

  seedBooks.forEach((book, bookIndex) => {
    if (book.chapters.length === 0 || book.final.length < 10 || book.final.length > 15) throw new Error(`Invalid seed for ${book.slug}`);
    const info = bookInsert.run(book.slug, book.title, book.author, bookIndex + 1, book.description,
      JSON.stringify(book.themes), addDays(start, bookIndex * 7), addDays(start, bookIndex * 7 + 6), book.sourceUrl, book.accent);
    const bookId = Number(info.lastInsertRowid);
    const chapterIds: number[] = [];
    book.chapters.forEach((chapter, chapterIndex) => {
      if (chapter.questions.length < 3 || chapter.questions.length > 5) throw new Error(`Invalid mini-test: ${book.slug}/${chapterIndex + 1}`);
      const row = chapterInsert.run(bookId, chapterIndex + 1, chapter.title, chapter.sourceLabel,
        chapter.summary, JSON.stringify(chapter.characters), JSON.stringify(chapter.quotes));
      const chapterId = Number(row.lastInsertRowid);
      chapterIds.push(chapterId);
      chapter.questions.forEach((question, index) => questionInsert.run(bookId, chapterId, chapterId, 'chapter', index + 1,
        question.text, JSON.stringify(question.options), question.correct, question.explanation, question.topic));
    });
    book.final.forEach((question, index) => {
      const referenceId = chapterIds[(question.reference ?? 0) - 1];
      if (!referenceId) throw new Error(`Missing chapter reference: ${book.slug}/${index + 1}`);
      questionInsert.run(bookId, null, referenceId, 'final', index + 1, question.text, JSON.stringify(question.options),
        question.correct, question.explanation, question.topic);
    });
  });
});
if (!building) seed();

export default db;
