-- SQLite. Source of truth: applied idempotently when the server opens app.db.
-- A production evolution must use real, versioned migrations, not only IF NOT EXISTS.
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS books (
  id INTEGER PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  author TEXT NOT NULL,
  position INTEGER NOT NULL UNIQUE CHECK (position > 0),
  description TEXT NOT NULL,
  themes TEXT NOT NULL CHECK (json_valid(themes)),
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL CHECK (end_date >= start_date),
  source_url TEXT NOT NULL,
  accent TEXT NOT NULL DEFAULT 'sage'
);

CREATE TABLE IF NOT EXISTS chapters (
  id INTEGER PRIMARY KEY,
  book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  position INTEGER NOT NULL CHECK (position > 0),
  title TEXT NOT NULL,
  summary TEXT NOT NULL,
  characters TEXT NOT NULL CHECK (json_valid(characters)),
  quotes TEXT NOT NULL CHECK (json_valid(quotes)),
  source_label TEXT NOT NULL,
  UNIQUE (book_id, position),
  UNIQUE (book_id, id)
);

-- Every question belongs to a book. For a mini-test chapter_id is filled;
-- for a final test it is NULL. reference_chapter_id anchors every explanation.
CREATE TABLE IF NOT EXISTS questions (
  id INTEGER PRIMARY KEY,
  book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  chapter_id INTEGER,
  reference_chapter_id INTEGER NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('chapter', 'final')),
  position INTEGER NOT NULL CHECK (position > 0),
  text TEXT NOT NULL,
  options TEXT NOT NULL CHECK (json_valid(options) AND json_type(options) = 'array' AND json_array_length(options) BETWEEN 2 AND 6),
  correct_option INTEGER NOT NULL CHECK (correct_option >= 0 AND correct_option < json_array_length(options)),
  explanation TEXT NOT NULL,
  topic TEXT NOT NULL,
  CHECK ((kind = 'chapter' AND chapter_id IS NOT NULL AND chapter_id = reference_chapter_id)
      OR (kind = 'final' AND chapter_id IS NULL)),
  FOREIGN KEY (book_id, chapter_id) REFERENCES chapters(book_id, id) ON DELETE CASCADE,
  FOREIGN KEY (book_id, reference_chapter_id) REFERENCES chapters(book_id, id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_chapter_question_order ON questions(chapter_id, position) WHERE kind = 'chapter';
CREATE UNIQUE INDEX IF NOT EXISTS uq_final_question_order ON questions(book_id, position) WHERE kind = 'final';

-- Marking read and passing are different states. Passing is sticky across retries.
CREATE TABLE IF NOT EXISTS user_progress (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  chapter_id INTEGER NOT NULL REFERENCES chapters(id) ON DELETE CASCADE,
  read_at TEXT NOT NULL,
  test_passed INTEGER NOT NULL DEFAULT 0 CHECK (test_passed IN (0, 1)),
  test_passed_at TEXT,
  PRIMARY KEY (user_id, chapter_id)
);

-- One row per complete test, plus one test_answers row per submitted question.
CREATE TABLE IF NOT EXISTS test_attempts (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  chapter_id INTEGER,
  kind TEXT NOT NULL CHECK (kind IN ('chapter', 'final')),
  total_questions INTEGER NOT NULL CHECK (total_questions > 0),
  correct_count INTEGER NOT NULL CHECK (correct_count >= 0 AND correct_count <= total_questions),
  passed INTEGER NOT NULL CHECK (passed IN (0, 1)),
  attempted_at TEXT NOT NULL,
  CHECK ((kind = 'chapter' AND chapter_id IS NOT NULL) OR (kind = 'final' AND chapter_id IS NULL)),
  FOREIGN KEY (book_id, chapter_id) REFERENCES chapters(book_id, id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_attempt_user_test ON test_attempts(user_id, book_id, kind, chapter_id, id DESC);
CREATE INDEX IF NOT EXISTS idx_attempt_final_passed ON test_attempts(user_id, book_id, kind, passed);

CREATE TABLE IF NOT EXISTS test_answers (
  attempt_id INTEGER NOT NULL REFERENCES test_attempts(id) ON DELETE CASCADE,
  question_id INTEGER NOT NULL REFERENCES questions(id) ON DELETE RESTRICT,
  answer INTEGER NOT NULL CHECK (answer >= 0),
  is_correct INTEGER NOT NULL CHECK (is_correct IN (0, 1)),
  PRIMARY KEY (attempt_id, question_id)
);
CREATE INDEX IF NOT EXISTS idx_chapters_book ON chapters(book_id, position);
CREATE INDEX IF NOT EXISTS idx_progress_user ON user_progress(user_id, chapter_id);
