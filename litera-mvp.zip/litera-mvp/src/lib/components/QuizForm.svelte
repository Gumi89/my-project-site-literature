<script lang="ts">
  import type { PublicQuestion, QuizFormState } from '$lib/types';
  import Icon from './Icon.svelte';
  export let questions: PublicQuestion[];
  export let form: QuizFormState | null = null;
</script>
<form method="POST" action="?/submit" class="quiz-form">
  {#if form?.message}<div class="alert" role="alert"><Icon name="info" />{form.message}</div>{/if}
  {#each questions as question, index (question.id)}
    <fieldset class="question-card">
      <legend class="sr-only">Вопрос {index + 1}: {question.text}</legend>
      <div class="question-number">ВОПРОС {String(index + 1).padStart(2, '0')} <span>/ {String(questions.length).padStart(2, '0')}</span></div>
      <p class="question-text">{question.text}</p>
      <div class="answer-options">
        {#each question.options as option, optionIndex}
          <label class="answer-option">
            <input type="radio" name={`q_${question.id}`} value={optionIndex} checked={form?.values?.[String(question.id)] === String(optionIndex)} required />
            <span>{option}</span>
          </label>
        {/each}
      </div>
    </fieldset>
  {/each}
  <div class="quiz-footer"><p>Проверьте ответы перед отправкой.<br />После проверки вы увидите разбор ошибок.</p><button class="btn btn-primary" type="submit">Проверить ответы <Icon name="arrow-right" /></button></div>
</form>
