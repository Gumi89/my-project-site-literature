<script lang="ts">
  export let name: string;
  export let size = 18;
  export let stroke = 1.7;
</script>
<svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width={stroke} stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
  {#if name === 'arrow-right'}<path d="M4 12h15M14 7l5 5-5 5" />
  {:else if name === 'arrow-left'}<path d="M20 12H5m5-5-5 5 5 5" />
  {:else if name === 'arrow-up-right'}<path d="M7 17 17 7M7 7h10v10" />
  {:else if name === 'book'}<path d="M4 5.5C6.5 4 9 4 12 5.5v14C9 18 6.5 18 4 19.5zM20 5.5C17.5 4 15 4 12 5.5v14c3-1.5 5.5-1.5 8 0z" />
  {:else if name === 'calendar'}<rect x="3.5" y="5.5" width="17" height="15" rx="2" /><path d="M7.5 3.5v4M16.5 3.5v4M3.5 10h17" />
  {:else if name === 'check'}<path d="m5 12 4 4 10-10" />
  {:else if name === 'chart'}<path d="M4 19.5h16M6 16V11M12 16V5M18 16V8" />
  {:else if name === 'clock'}<circle cx="12" cy="12" r="8.5" /><path d="M12 7v5l3 2" />
  {:else if name === 'list'}<path d="M9 6h10M9 12h10M9 18h10M4 6h.01M4 12h.01M4 18h.01" />
  {:else if name === 'spark'}<path d="M12 3c.9 4.2 2.8 6.1 7 7-4.2.9-6.1 2.8-7 7-.9-4.2-2.8-6.1-7-7 4.2-.9 6.1-2.8 7-7ZM19 16l.4 1.6L21 18l-1.6.4L19 20l-.4-1.6L17 18l1.6-.4z" />
  {:else if name === 'lock'}<rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v2"/>
  {:else if name === 'rotate'}<path d="M4 10a8 8 0 1 1 1.7 6M4 4v6h6" />
  {:else if name === 'quote'}<path d="M10 7H6v5h4v4H5v-4c0-3 1.5-5 5-5ZM19 7h-4v5h4v4h-5v-4c0-3 1.5-5 5-5Z" />
  {:else if name === 'people'}<circle cx="9" cy="8" r="3"/><path d="M3.5 19v-1.5A4.5 4.5 0 0 1 8 13h2a4.5 4.5 0 0 1 4.5 4.5V19M16 5.4a3 3 0 0 1 0 5.8M17 13.3a4 4 0 0 1 3.5 4V19"/>
  {:else if name === 'info'}<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>
  {:else if name === 'chevron'}<path d="m9 5 7 7-7 7" />
  {/if}
</svg>
