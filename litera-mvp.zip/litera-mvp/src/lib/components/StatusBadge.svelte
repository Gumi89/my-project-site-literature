<script lang="ts">
  import type { BookStatus, ChapterStatus } from '$lib/types';
  export let status: BookStatus | ChapterStatus;
  $: label = ({ not_started: 'Не начата', reading: 'Читаю', finished: 'Прочитана', not_read: 'Не прочитана', read: 'Прочитана', passed: 'Тест сдан' })[status];
  $: tone = status === 'finished' || status === 'passed' ? 'success' : status === 'reading' || status === 'read' ? 'active' : 'neutral';
</script>
<span class={`status-badge ${tone}`}><span class="status-dot"></span>{label}</span>
