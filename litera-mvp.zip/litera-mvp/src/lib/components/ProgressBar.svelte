<script lang="ts">
  import { percent } from '$lib/format';
  export let value: number;
  export let total: number;
  export let label = 'Прогресс';
  $: percentage = percent(value, total);
</script>
<div class="progress-track" role="progressbar" aria-label={label} aria-valuemin="0" aria-valuemax="100" aria-valuenow={percentage}>
  <div class="progress-fill" style={`width: ${percentage}%`}></div>
</div>
