<script lang="ts">
  import type { ScheduleBook } from '$lib/types';
  export let book: ScheduleBook;
  export let small = false;
</script>
<div class:small class={`book-cover ${book.accent}`} aria-hidden="true">
  <span class="cover-index">ЛИТЕРАТУРА <i> / </i> {String(book.position).padStart(2, '0')}</span>
  <span class="cover-orbit"></span><span class="cover-orbit second"></span>
  <span class="cover-decoration">✳</span>
  <div class="cover-copy"><span>{book.author}</span><strong>{book.title}</strong></div>
  <span class="cover-bottom">ЧИТАТЕЛЬСКИЙ ПЛАН <b>✦</b></span>
</div>
