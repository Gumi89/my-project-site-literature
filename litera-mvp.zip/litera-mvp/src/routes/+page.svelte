<script lang="ts">
  import type { PageData } from './$types';
  import Icon from '$lib/components/Icon.svelte';
  import ProgressBar from '$lib/components/ProgressBar.svelte';
  import StatusBadge from '$lib/components/StatusBadge.svelte';
  import BookCover from '$lib/components/BookCover.svelte';
  import { dateRange, plural } from '$lib/format';
  export let data: PageData;
  $: next = data.books.find((book) => book.status === 'reading') ?? data.books.find((book) => book.status === 'not_started');
</script>
<svelte:head><title>План чтения — Литера</title></svelte:head>
<div class="shell home">
  <section class="hero">
    <div>
      <div class="eyebrow"><span class="eyebrow-dot"></span> ВАШ ЧИТАТЕЛЬСКИЙ ПЛАН</div>
      <h1>Хорошие книги.<br /><em>Уверенные ответы.</em></h1>
      <p>Готовьтесь к ЕГЭ по литературе в своём темпе:<br class="desktop-break" /> читайте, проверяйте себя и замечайте прогресс.</p>
    </div>
    <div class="hero-aside" aria-hidden="true">
      <div class="hero-flower">✳</div>
      <div><span>ПОНЕМНОГУ, НО РЕГУЛЯРНО</span><strong>Всё начинается<br />с первой страницы.</strong></div>
    </div>
  </section>

  <section class="overview card" aria-label="Общий прогресс">
    <div class="overview-main">
      <div class="overview-top"><div><div class="mini-label">ВАШ ПРОГРЕСС</div><h2>Каждая книга имеет значение</h2></div><div class="stat-icon"><Icon name="book" size={20}/></div></div>
      <div class="progress-line"><strong>Прочитано {data.stats.finishedBooks} из {data.stats.totalBooks} {plural(data.stats.totalBooks, 'книги', 'книг', 'книг')}</strong><span>{data.stats.totalBooks ? Math.round(data.stats.finishedBooks * 100 / data.stats.totalBooks) : 0}%</span></div>
      <ProgressBar value={data.stats.finishedBooks} total={data.stats.totalBooks} label="Прочитано книг" />
    </div>
    <div class="overview-stat"><div class="stat-icon light"><Icon name="list" size={19}/></div><div><span>ПРОЧИТАНО ГЛАВ / БЛОКОВ</span><strong>{data.stats.readChapters}<small> / {data.stats.totalChapters}</small></strong><p>отмечено как прочитано</p></div></div>
    <div class="overview-stat last"><div class="stat-icon peach"><Icon name="chart" size={19}/></div><div><span>СРЕДНИЙ БАЛЛ</span><strong>{data.stats.averageScore === null ? '—' : `${data.stats.averageScore}%`}</strong><p>по последним попыткам</p></div></div>
  </section>

  <div class="section-heading"><div><div class="eyebrow">ВАША ПРОГРАММА</div><h2 class="section-title">План чтения</h2><p>Двигайтесь по списку и отмечайте прочитанное.</p></div><div class="heading-meta"><Icon name="calendar" size={16} /> {data.books.length} {plural(data.books.length, 'произведение', 'произведения', 'произведений')} в плане</div></div>

  <div class="home-grid">
    <section class="schedule" aria-label="Расписание книг">
      {#each data.books as book (book.id)}
        <article class="book-row card">
          <BookCover {book} />
          <div class="book-content">
            <div class="book-meta"><span class="book-number">КНИГА {String(book.position).padStart(2, '0')}</span><StatusBadge status={book.status} /><span class="book-date"><Icon name="calendar" size={14} /> {dateRange(book.startDate, book.endDate)}</span></div>
            <a class="book-name" href={`/books/${book.slug}`}><h3>{book.title}</h3></a>
            <p class="book-author">{book.author}</p>
            <div class="book-themes">{#each book.themes.slice(0, 2) as theme}<span>{theme}</span>{/each}</div>
            <div class="book-bottom"><div class="book-progress"><div><span>Этапы</span><strong>{book.passedCount} / {book.chapterCount}</strong></div><ProgressBar value={book.passedCount} total={book.chapterCount} label={`Пройдено этапов: ${book.title}`} /></div><a class="book-action" href={`/books/${book.slug}`}>{book.status === 'not_started' ? 'Открыть книгу' : book.status === 'finished' ? 'К книге' : 'Продолжить'} <Icon name="arrow-right" size={16}/></a></div>
          </div>
        </article>
      {/each}
    </section>
    <aside class="home-sidebar">
      <div class="next-card">
        <div class="next-top"><span class="mini-label">ВАШ СЛЕДУЮЩИЙ ШАГ</span><span class="next-arrow"><Icon name="arrow-up-right" size={17}/></span></div>
        {#if next}
          <h3>{next.status === 'reading' ? 'Продолжим читать?' : 'Начнём с первой книги?'}</h3>
          <p>{next.status === 'reading' ? 'Вы уже начали эту историю. Вернитесь к ней, когда будете готовы.' : 'Откройте произведение, прочитайте первый блок и проверьте себя.'}</p>
          <div class="next-book"><BookCover book={next} small /><div><strong>{next.title}</strong><span>{next.author}</span><a href={`/books/${next.slug}`}>К книге <Icon name="arrow-right" size={14}/></a></div></div>
        {:else}
          <h3>План прочитан</h3><p>Все книги завершены. Можно вернуться к любому произведению и пересдать тест.</p><a class="inline-link" href="/dashboard">Посмотреть прогресс <Icon name="arrow-right" size={14}/></a>
        {/if}
      </div>
      <div class="how-card card"><div class="mini-label">КАК ЭТО РАБОТАЕТ</div><h3>Просто, шаг за шагом</h3><ol><li><span>01</span><div><strong>Читайте по плану</strong><p>Каждая книга разбита на удобные этапы.</p></div></li><li><span>02</span><div><strong>Проверяйте себя</strong><p>После этапа — короткий тест с разбором.</p></div></li><li><span>03</span><div><strong>Закрепляйте прочитанное</strong><p>В конце книги вас ждёт итоговый тест.</p></div></li></ol></div>
      <div class="side-note"><Icon name="info" size={15}/><span>Краткие содержания помогают повторять, но не заменяют чтение оригинала.</span></div>
    </aside>
  </div>
</div>
<style>
.home{padding-top:48px}.hero{display:flex;justify-content:space-between;align-items:center;margin-bottom:36px}.hero .eyebrow{margin-bottom:15px}.hero h1{font:400 49px/1.12 var(--serif);letter-spacing:-1.8px}.hero h1 em{font-style:italic;color:#688f7a}.hero p{font-size:13px;color:#84938a;line-height:1.75;margin-top:14px}.hero-aside{display:flex;align-items:center;gap:16px;padding-right:50px}.hero-flower{width:57px;height:57px;border:1px solid #e1eae1;border-radius:50%;display:grid;place-items:center;color:#91ad9c;font:34px var(--serif)}.hero-aside span{font-size:9px;letter-spacing:.11em;font-weight:800;color:#a7b4a9}.hero-aside strong{display:block;margin-top:7px;font:italic 16px/1.35 var(--serif);color:#6c8174}.overview{display:grid;grid-template-columns:1.38fr 1fr 1fr;min-height:148px;box-shadow:0 6px 23px #304c3910}.overview-main{padding:23px 28px 21px}.overview-top{display:flex;justify-content:space-between;align-items:start;margin-bottom:24px}.mini-label{font-size:9px;font-weight:800;letter-spacing:.13em;color:#88a092}.overview-top h2{font:400 19px var(--serif);margin-top:7px}.stat-icon{width:36px;height:36px;border-radius:9px;display:grid;place-items:center;background:#eff5ee;color:#749782}.stat-icon.light{background:#eef4ef}.stat-icon.peach{background:#fbf1e8;color:#c59c7d}.progress-line{display:flex;justify-content:space-between;margin-bottom:9px;font-size:11px}.progress-line strong{font-weight:700;color:#536d5e}.progress-line span{color:#9aa99c}.overview-stat{border-left:1px solid #edf0eb;display:flex;align-items:center;gap:15px;padding:25px 26px}.overview-stat>div:last-child>span{font-size:9px;letter-spacing:.1em;font-weight:800;color:#a0aea3}.overview-stat strong{display:block;font:400 29px/1.15 var(--serif);margin:7px 0 5px}.overview-stat strong small{font:400 17px var(--serif);color:#a3b1a6}.overview-stat p{font-size:10px;color:#a0ada3;white-space:nowrap}.section-heading{display:flex;align-items:end;justify-content:space-between;margin:51px 0 21px}.section-heading .eyebrow{margin-bottom:9px}.section-heading p{font-size:12px;color:#92a096;margin-top:7px}.heading-meta{display:flex;align-items:center;gap:7px;color:#9aa99e;font-size:11px}.home-grid{display:grid;grid-template-columns:minmax(0,1fr) 295px;gap:22px;align-items:start}.schedule{display:grid;gap:14px}.book-row{padding:17px;display:flex;gap:22px;min-width:0}.book-content{min-width:0;flex:1;display:flex;flex-direction:column}.book-meta{display:flex;align-items:center;gap:12px}.book-number{font-size:9px;letter-spacing:.11em;font-weight:800;color:#a0aea3}.book-date{margin-left:auto;display:flex;gap:5px;align-items:center;color:#9aa99e;font-size:11px;white-space:nowrap}.book-name{width:fit-content}.book-name:hover{color:#54836c}.book-name h3{font:400 23px/1.2 var(--serif);letter-spacing:-.4px;margin:12px 0 4px}.book-author{font-size:12px;color:#87978b}.book-themes{display:flex;gap:6px;margin-top:12px;flex-wrap:wrap}.book-themes span{font-size:10px;color:#8aa08f}.book-themes span+span:before{content:'·';padding-right:6px;color:#c6d1c5}.book-bottom{margin-top:auto;display:flex;align-items:end;justify-content:space-between;gap:20px}.book-progress{width:min(180px,50%)}.book-progress>div:first-child{display:flex;justify-content:space-between;color:#9aa99d;font-size:10px;margin-bottom:8px}.book-progress strong{color:#728c79}.book-action{display:inline-flex;align-items:center;gap:8px;font-size:11px;font-weight:700;color:#527968;white-space:nowrap}.book-action:hover{text-decoration:underline}.home-sidebar{display:grid;gap:14px}.next-card{border-radius:12px;padding:22px;background:#eaf1e9;border:1px solid #e2ebe1}.next-top{display:flex;align-items:center;justify-content:space-between}.next-arrow{width:29px;height:29px;display:grid;place-items:center;border:1px solid #c8daca;border-radius:50%;color:#668c75}.next-card h3,.how-card h3{font:400 21px/1.2 var(--serif);letter-spacing:-.3px;margin-top:10px}.next-card>p{font-size:11px;line-height:1.7;color:#859a8a;margin:10px 0 17px}.next-book{display:flex;gap:13px;border-top:1px solid #d6e4d6;padding-top:16px;align-items:center}.next-book>div:last-child{min-width:0}.next-book strong{font:400 16px/1.2 var(--serif);display:block}.next-book span{display:block;color:#91a496;font-size:10px;margin-top:6px}.next-book a{display:inline-flex;gap:6px;align-items:center;color:#4f7a65;font-size:11px;font-weight:700;margin-top:15px}.how-card{padding:22px}.how-card h3{margin-bottom:19px}.how-card ol{list-style:none;padding:0;margin:0;display:grid;gap:16px}.how-card li{display:flex;gap:12px}.how-card li>span{font:italic 15px var(--serif);color:#b3c8b5}.how-card li strong{font-size:11px;color:#536d5b}.how-card li p{font-size:10px;line-height:1.5;color:#a0aca2;margin-top:4px}.side-note{display:flex;gap:8px;color:#9aa99d;font-size:10px;line-height:1.6;padding:0 6px}.side-note :global(svg){flex:none;margin-top:1px}
@media(max-width:900px){.home-grid{grid-template-columns:minmax(0,1fr) 250px}.overview{grid-template-columns:1.2fr 1fr 1fr}.overview-stat{padding:20px 16px}.overview-stat .stat-icon{display:none}.hero-aside{padding-right:0}.book-row{gap:15px}.book-date{font-size:10px}}
@media(max-width:750px){.home{padding-top:35px}.hero{margin-bottom:25px}.hero h1{font-size:39px}.hero-aside{display:none}.overview{grid-template-columns:1fr 1fr}.overview-main{grid-column:1/-1;border-bottom:1px solid #edf0eb;padding:20px}.overview-top{margin-bottom:19px}.overview-stat{padding:19px 20px;border-left:0}.overview-stat.last{border-left:1px solid #edf0eb}.overview-stat strong{font-size:25px}.section-heading{margin:38px 0 17px}.heading-meta{display:none}.home-grid{grid-template-columns:1fr}.home-sidebar{grid-template-columns:1fr 1fr;align-items:start}.side-note{grid-column:1/-1}.book-row{padding:14px}.book-row :global(.book-cover){width:105px;min-width:105px;height:150px}.book-date{margin-left:auto}.book-name h3{font-size:21px;margin-top:10px}.book-themes{margin-top:9px}}
@media(max-width:480px){.hero h1{font-size:35px}.desktop-break{display:none}.hero p{font-size:12px}.home-sidebar{grid-template-columns:1fr}.side-note{grid-column:auto}.book-row{gap:13px}.book-row :global(.book-cover){width:90px;min-width:90px;height:138px;padding:10px 9px}.book-row :global(.cover-copy strong){font-size:14px}.book-row :global(.sage .cover-copy strong){font-size:10px}.book-meta{gap:7px;flex-wrap:wrap}.book-date{width:100%;margin:0}.book-name h3{font-size:19px;margin-top:8px}.book-themes{display:none}.book-progress{width:100%;max-width:115px}.book-action{font-size:10px;gap:4px}.book-bottom{gap:8px}.section-title{font-size:27px}}
</style>
