import type { PageServerLoad } from './$types';
import { getSchedule, getDashboard } from '$lib/server/repository';

export const load: PageServerLoad = () => ({ books: getSchedule(), stats: getDashboard() });
