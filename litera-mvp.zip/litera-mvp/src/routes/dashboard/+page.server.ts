import type { PageServerLoad } from './$types';
import { getDashboard, getSchedule } from '$lib/server/repository';

export const load: PageServerLoad = () => ({ stats: getDashboard(), books: getSchedule() });
