import { error } from '@sveltejs/kit';
import type { PageServerLoad } from './$types';
import { getAttempt, getChapters } from '$lib/server/repository';

export const load: PageServerLoad = ({ params }) => {
  const attempt = getAttempt(params.id);
  if (!attempt) error(404, 'Попытка не найдена');
  const nextChapter = getChapters(attempt.bookId).find((chapter) => !chapter.testPassed);
  return { attempt, nextChapter: nextChapter ?? null };
};
