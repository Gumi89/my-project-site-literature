<script lang="ts">
  import type { PageData } from './$types';
  import Icon from '$lib/components/Icon.svelte';
  import { plural } from '$lib/format';
  export let data: PageData;
  $: attempt = data.attempt;
  $: wrong = attempt.answers.filter((answer) => !answer.isCorrect);
  $: retryUrl = attempt.kind === 'chapter' ? `/books/${attempt.bookSlug}/chapters/${attempt.chapterId}/test` : `/books/${attempt.bookSlug}/final`;
</script>
<svelte:head><title>Результат теста — Литера</title></svelte:head>
<div class="shell page-wrap"><div class="result-layout">
  <a class="back-link" href={`/books/${attempt.bookSlug}`}><Icon name="arrow-left" size={15}/> К книге</a>
  <section class="result-hero card">
    <div class:needs-work={!attempt.passed} class="result-symbol"><Icon name={attempt.passed ? 'check' : 'book'} size={27}/></div>
    <div class="eyebrow">{attempt.kind === 'chapter' ? 'МИНИ-ТЕСТ' : 'ИТОГОВЫЙ ТЕСТ'} · {attempt.bookTitle.toUpperCase()}</div>
    <h1>{attempt.passed ? 'Тест пройден' : 'Есть что повторить'}</h1>
    <p>{attempt.passed ? (attempt.kind === 'final' ? 'Итоговый тест сдан — книга отмечена прочитанной.' : 'Хорошая работа. Вы закрепили этот этап.') : 'Ничего страшного: посмотрите разбор и попробуйте ещё раз.'}</p>
    <div class="score"><strong>{attempt.score}%</strong><span>правильных ответов<br/><b>{attempt.correctCount} из {attempt.totalQuestions}</b></span></div>
    <div class="result-actions">
      {#if attempt.passed && attempt.kind === 'chapter' && data.nextChapter}<a class="btn btn-primary" href={`/books/${attempt.bookSlug}/chapters/${data.nextChapter.id}`}>К следующему этапу <Icon name="arrow-right" size={16}/></a>
      {:else}<a class="btn btn-primary" href={`/books/${attempt.bookSlug}`}>Вернуться к книге <Icon name="arrow-right" size={16}/></a>{/if}
      <a class="btn btn-secondary" href={retryUrl}><Icon name="rotate" size={15}/> Пересдать тест</a>
    </div>
  </section>
  <section class="review"><div class="review-heading"><div><div class="eyebrow">ОБРАТНАЯ СВЯЗЬ</div><h2 class="section-title">Разбор ответов</h2></div><span>{wrong.length} {plural(wrong.length,'ошибка','ошибки','ошибок')}</span></div>
    {#if wrong.length === 0}<div class="all-correct card"><span><Icon name="check" size={18}/></span><div><strong>Все ответы верны</strong><p>Отлично — можно двигаться дальше или пересдать тест позже.</p></div></div>
    {:else}<div class="review-list">{#each wrong as answer}<article class="review-card card"><div class="review-top"><span>ВОПРОС НА ПОВТОРЕНИЕ</span><span>{answer.topic}</span></div><h3>{answer.text}</h3><div class="your-answer"><span>ВАШ ОТВЕТ</span><p>{answer.options[answer.answer]}</p></div><div class="correct-answer"><span>ПРАВИЛЬНЫЙ ОТВЕТ</span><p>{answer.options[answer.correctOption]}</p></div><div class="explanation"><strong>Почему так?</strong><p>{answer.explanation}</p><a href={`/books/${attempt.bookSlug}/chapters/${answer.referenceId}`}>Повторить: {answer.referenceLabel} <Icon name="arrow-right" size={14}/></a></div></article>{/each}</div>{/if}
  </section>
</div></div>
<style>
.result-layout{max-width:800px;margin:0 auto}.result-hero{text-align:center;padding:35px 30px}.result-symbol{width:56px;height:56px;margin:0 auto 18px;border-radius:50%;display:grid;place-items:center;background:#e9f4ea;color:#6b9a79}.result-symbol.needs-work{background:#faf0e5;color:#bb8e67}.result-hero .eyebrow{justify-content:center}.result-hero h1{font:400 38px var(--serif);letter-spacing:-1px;margin:12px 0 8px}.result-hero>p{font-size:13px;color:#92a197;line-height:1.6}.score{display:inline-flex;align-items:center;text-align:left;gap:15px;margin:23px 0}.score>strong{font:400 41px var(--serif);color:#5f8b70}.score>span{font-size:11px;line-height:1.55;color:#a0aea3}.score b{color:#819689}.result-actions{display:flex;justify-content:center;flex-wrap:wrap;gap:9px}.review{margin-top:40px}.review-heading{display:flex;justify-content:space-between;align-items:end;margin-bottom:16px}.review-heading .eyebrow{margin-bottom:8px}.review-heading>span{font-size:11px;color:#99a99c}.review-list{display:grid;gap:12px}.review-card{padding:23px 26px}.review-top{display:flex;justify-content:space-between;gap:15px;font-size:9px;letter-spacing:.1em;font-weight:800;color:#b7997e}.review-top span+span{color:#9eafa2;letter-spacing:0;font-size:10px}.review-card h3{font:400 20px/1.3 var(--serif);margin:12px 0 16px}.your-answer,.correct-answer{display:inline-block;vertical-align:top;width:49%;padding-right:15px}.your-answer span,.correct-answer span{font-size:9px;letter-spacing:.08em;font-weight:800;color:#b6a49a}.correct-answer span{color:#84a492}.your-answer p,.correct-answer p{font-size:12px;color:#7e8f83;line-height:1.5;margin-top:6px}.explanation{margin-top:17px;padding:15px;background:#f5f8f3;border-radius:8px}.explanation strong{font-size:11px;color:#64816d}.explanation p{font-size:12px;color:#718879;line-height:1.65;margin:6px 0 10px}.explanation a{display:inline-flex;gap:7px;align-items:center;color:#608b72;font-size:11px;font-weight:700}.explanation a:hover{text-decoration:underline}.all-correct{display:flex;gap:15px;padding:22px}.all-correct>span{width:32px;height:32px;border-radius:50%;background:#eaf4eb;color:#6b9a79;display:grid;place-items:center}.all-correct strong{font:400 18px var(--serif)}.all-correct p{font-size:12px;color:#9ba99e;margin-top:6px}
@media(max-width:480px){.result-hero{padding:27px 18px}.result-hero h1{font-size:31px}.result-actions{flex-direction:column}.review-card{padding:20px}.your-answer,.correct-answer{display:block;width:100%;margin-top:12px}}
</style>
