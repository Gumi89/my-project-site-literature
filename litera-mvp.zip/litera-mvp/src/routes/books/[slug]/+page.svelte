<script lang="ts">
  import type { PageData } from './$types';
  import Icon from '$lib/components/Icon.svelte';
  import ProgressBar from '$lib/components/ProgressBar.svelte';
  import StatusBadge from '$lib/components/StatusBadge.svelte';
  import BookCover from '$lib/components/BookCover.svelte';
  import { dateRange, plural } from '$lib/format';
  export let data: PageData;
  $: unlocked = data.book.chapterCount > 0 && data.book.passedCount === data.book.chapterCount;
</script>
<svelte:head><title>{data.book.title} — Литера</title></svelte:head>
<div class="shell page-wrap">
  <a class="back-link" href="/"><Icon name="arrow-left" size={15}/> К плану чтения</a>
  <section class="book-hero card">
    <BookCover book={data.book}/>
    <div class="book-info">
      <div class="topline"><span class="eyebrow">ПРОИЗВЕДЕНИЕ {String(data.book.position).padStart(2,'0')}</span><StatusBadge status={data.book.status}/></div>
      <h1>{data.book.title}</h1><p class="author">{data.book.author}</p>
      <p class="description">{data.book.description}</p>
      <div class="theme-line"><span>ТЕМЫ ДЛЯ ЕГЭ</span>{#each data.book.themes as theme}<span class="tag">{theme}</span>{/each}</div>
      <a class="source-link" href={data.book.sourceUrl} target="_blank" rel="noopener noreferrer">Открыть текст произведения <Icon name="arrow-up-right" size={14}/></a>
    </div>
    <div class="hero-date"><Icon name="calendar" size={15}/>{dateRange(data.book.startDate, data.book.endDate)}</div>
  </section>
  {#if data.locked}<div class="alert locked-alert" role="alert"><Icon name="lock"/>Итоговый тест откроется, когда вы сдадите тесты после всех этапов.</div>{/if}
  <div class="book-grid">
    <section class="chapter-section">
      <div class="chapter-heading"><div><div class="eyebrow">ВАШ МАРШРУТ ЧТЕНИЯ</div><h2 class="section-title">Этапы чтения</h2><p>Прочитайте этап, затем пройдите небольшой тест.</p></div><span>{data.chapters.length} {plural(data.chapters.length, 'этап', 'этапа', 'этапов')}</span></div>
      <div class="chapter-list card">
        {#each data.chapters as chapter (chapter.id)}
          <a class="chapter-row" href={`/books/${data.book.slug}/chapters/${chapter.id}`}>
            <span class:passed={chapter.testPassed} class="chapter-number">{#if chapter.testPassed}<Icon name="check" size={16}/>{:else}{String(chapter.position).padStart(2,'0')}{/if}</span>
            <span class="chapter-copy"><span>{chapter.sourceLabel}</span><strong>{chapter.title}</strong></span>
            <StatusBadge status={chapter.status}/><span class="row-chevron"><Icon name="chevron" size={16}/></span>
          </a>
        {/each}
      </div>
    </section>
    <aside class="book-sidebar">
      <div class="book-progress-card card"><div class="eyebrow">ПРОГРЕСС ПО КНИГЕ</div><div class="fraction">{data.book.passedCount}<span> / {data.book.chapterCount}</span></div><p>этапов сдано</p><ProgressBar value={data.book.passedCount} total={data.book.chapterCount} label="Тесты этапов"/><div class="progress-caption">Отметили прочитанными: {data.book.readCount} из {data.book.chapterCount}</div></div>
      <div class="final-card"><div class="final-icon"><Icon name="book" size={19}/></div><div class="eyebrow">ФИНАЛЬНЫЙ ШАГ</div><h3>Итоговый тест</h3><p>Когда сдадите все мини-тесты, проверьте понимание книги целиком.</p><div class="final-meta"><Icon name="list" size={15}/> {data.finalQuestionCount} {plural(data.finalQuestionCount, 'вопрос', 'вопроса', 'вопросов')} <span>·</span> проходной балл 70%</div>
        {#if unlocked}<a href={`/books/${data.book.slug}/final`} class="btn btn-primary final-btn">{data.book.finalPassed ? 'Пересдать тест' : 'Книга прочитана'} <Icon name="arrow-right" size={16}/></a>
        {:else}<button class="btn final-btn" disabled>Книга прочитана <Icon name="lock" size={15}/></button><small>Доступно после всех мини-тестов</small>{/if}
      </div>
    </aside>
  </div>
</div>
<style>
.book-hero{position:relative;display:flex;gap:27px;padding:23px}.book-hero :global(.book-cover){width:150px;min-width:150px;height:198px;padding:16px 15px}.book-hero :global(.cover-copy strong){font-size:24px}.book-hero :global(.sage .cover-copy strong){font-size:17px}.book-hero :global(.cover-copy span){font-size:8px}.book-hero :global(.cover-copy){margin-top:30px}.book-info{padding:3px 0;max-width:690px}.topline{display:flex;align-items:center;gap:12px}.book-info h1{font:400 38px/1.1 var(--serif);letter-spacing:-1px;margin:13px 0 5px}.author{font-size:13px;color:#8e9e91}.description{color:#6f8275;font-size:13px;line-height:1.7;margin:16px 0}.theme-line{display:flex;align-items:center;gap:6px;flex-wrap:wrap}.theme-line>span:first-child{font-size:9px;letter-spacing:.09em;font-weight:800;color:#a5b2a7;margin-right:4px}.source-link{display:inline-flex;align-items:center;gap:5px;font-size:11px;color:#648878;font-weight:700;margin-top:15px}.source-link:hover{text-decoration:underline}.hero-date{position:absolute;right:25px;top:27px;display:flex;align-items:center;gap:6px;color:#9aa99d;font-size:11px}.locked-alert{margin-top:15px}.book-grid{display:grid;grid-template-columns:minmax(0,1fr) 295px;gap:25px;margin-top:43px}.chapter-heading{display:flex;align-items:end;justify-content:space-between;margin-bottom:17px}.chapter-heading .eyebrow{margin-bottom:8px}.chapter-heading p{font-size:12px;color:#99a69b;margin-top:6px}.chapter-heading>span{color:#a0ada3;font-size:11px}.chapter-list{overflow:hidden}.chapter-row{display:flex;align-items:center;gap:15px;padding:17px 20px;border-bottom:1px solid #edf0eb;transition:background .15s}.chapter-row:last-child{border-bottom:0}.chapter-row:hover{background:#f9fbf8}.chapter-number{width:37px;height:37px;flex:none;display:grid;place-items:center;border:1px solid #e6ece5;border-radius:9px;color:#9caf9f;font:italic 15px var(--serif)}.chapter-number.passed{background:#e8f2ea;color:#6d9a7e;border-color:#e8f2ea}.chapter-copy{flex:1;min-width:0}.chapter-copy>span{display:block;text-transform:uppercase;font-size:9px;font-weight:800;letter-spacing:.09em;color:#9aab9d;margin-bottom:5px}.chapter-copy strong{font:400 17px var(--serif)}.row-chevron{color:#b8c6b9}.book-sidebar{display:grid;gap:14px}.book-progress-card{padding:23px}.fraction{font:400 31px var(--serif);margin:12px 0 2px}.fraction span{font-size:20px;color:#b4c1b5}.book-progress-card>p{color:#94a397;font-size:11px;margin-bottom:17px}.progress-caption{font-size:10px;color:#9baa9e;margin-top:11px}.final-card{padding:23px;background:#eef4ed;border:1px solid #e6eee5;border-radius:12px}.final-icon{width:37px;height:37px;border-radius:9px;background:#dfece0;color:#72977d;display:grid;place-items:center;margin-bottom:20px}.final-card h3{font:400 21px var(--serif);margin:9px 0}.final-card p{font-size:11px;color:#84998a;line-height:1.7}.final-meta{display:flex;align-items:center;gap:6px;color:#89a091;font-size:10px;margin:17px 0}.final-btn{width:100%;justify-content:space-between}.final-card small{display:block;text-align:center;color:#a1b0a2;font-size:10px;margin-top:9px}
@media(max-width:750px){.book-hero{gap:17px;padding:16px}.book-hero :global(.book-cover){width:108px;min-width:108px;height:150px;padding:12px}.book-hero :global(.cover-copy strong){font-size:17px}.book-hero :global(.sage .cover-copy strong){font-size:12px}.book-hero :global(.cover-copy){margin-top:19px}.book-info h1{font-size:29px}.book-info .description{font-size:12px;margin:10px 0}.hero-date{position:static;display:none}.book-grid{grid-template-columns:1fr;margin-top:35px}.book-sidebar{grid-template-columns:1fr 1fr}.book-progress-card,.final-card{padding:20px}.chapter-copy strong{font-size:16px}}
@media(max-width:480px){.book-hero{align-items:start}.book-hero :global(.book-cover){width:75px;min-width:75px;height:108px;padding:9px}.book-hero :global(.cover-copy strong){font-size:12px}.book-hero :global(.sage .cover-copy strong){font-size:8px}.book-hero :global(.cover-copy span){font-size:5px}.book-hero :global(.cover-copy){margin-top:10px}.book-hero :global(.cover-index),.book-hero :global(.cover-bottom){font-size:4px}.book-hero :global(.cover-decoration){font-size:18px}.book-info h1{font-size:24px;margin:10px 0 4px}.topline{align-items:start;flex-wrap:wrap}.book-info .description{font-size:11px}.theme-line>span:first-child{width:100%}.book-sidebar{grid-template-columns:1fr}.chapter-row{padding:15px 13px;gap:9px}.chapter-row :global(.status-badge){font-size:9px;padding:5px 7px}}
</style>
