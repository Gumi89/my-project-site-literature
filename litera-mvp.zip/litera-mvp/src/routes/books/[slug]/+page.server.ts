import { error } from '@sveltejs/kit';
import type { PageServerLoad } from './$types';
import { getBook, getChapters, getPublicQuestions } from '$lib/server/repository';

export const load: PageServerLoad = ({ params, url }) => {
  const book = getBook(params.slug);
  if (!book) error(404, 'Книга не найдена');
  return { book, chapters: getChapters(book.id), finalQuestionCount: getPublicQuestions(book.id, 'final', null).length, locked: url.searchParams.has('locked') };
};
