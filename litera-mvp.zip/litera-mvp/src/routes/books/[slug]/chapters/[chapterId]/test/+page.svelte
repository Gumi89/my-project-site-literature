<script lang="ts">
  import type { ActionData, PageData } from './$types';
  import Icon from '$lib/components/Icon.svelte';
  import QuizForm from '$lib/components/QuizForm.svelte';
  import { plural } from '$lib/format';
  export let data: PageData;
  export let form: ActionData;
</script>
<svelte:head><title>Мини-тест — {data.chapter.title} — Литера</title></svelte:head>
<div class="shell page-wrap"><div class="quiz-layout">
  <a class="back-link" href={`/books/${data.book.slug}/chapters/${data.chapter.id}`}><Icon name="arrow-left" size={15}/> Вернуться к этапу</a>
  <header class="quiz-heading"><div class="eyebrow"><span class="eyebrow-dot"></span> МИНИ-ТЕСТ · {data.chapter.sourceLabel.toUpperCase()}</div><h1>Проверим, что запомнилось</h1><p>{data.book.title} · {data.chapter.title}</p><div class="quiz-meta"><span><Icon name="list" size={15}/> {data.questions.length} {plural(data.questions.length,'вопрос','вопроса','вопросов')}</span><span><Icon name="check" size={15}/> Для зачёта — от {data.passPercent}%</span></div></header>
  <QuizForm questions={data.questions} {form}/>
</div></div>
