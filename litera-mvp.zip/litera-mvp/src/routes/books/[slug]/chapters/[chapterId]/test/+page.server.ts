import { error, fail, redirect } from '@sveltejs/kit';
import type { Actions, PageServerLoad } from './$types';
import { getBook, getChapter, getPublicQuestions } from '$lib/server/repository';
import { PASS_PERCENT, submitQuiz } from '$lib/server/quiz';

function checkedContext(slug: string, chapterId: string) {
  const book = getBook(slug);
  if (!book) error(404, 'Книга не найдена');
  const chapter = getChapter(book.id, chapterId);
  if (!chapter) error(404, 'Глава не найдена');
  if (!chapter.readAt) redirect(303, `/books/${book.slug}/chapters/${chapter.id}`);
  return { book, chapter };
}
export const load: PageServerLoad = ({ params }) => {
  const { book, chapter } = checkedContext(params.slug, params.chapterId);
  const questions = getPublicQuestions(book.id, 'chapter', chapter.id);
  if (!questions.length) error(503, 'Вопросы для главы пока не добавлены');
  return { book, chapter, questions, passPercent: PASS_PERCENT };
};
export const actions: Actions = {
  submit: async ({ params, request }) => {
    const { book, chapter } = checkedContext(params.slug, params.chapterId);
    const result = submitQuiz(book.id, 'chapter', chapter.id, await request.formData());
    if (!result.ok) return fail(400, { message: result.message, values: result.values });
    redirect(303, `/attempts/${result.attemptId}`);
  }
};
