import { error, redirect } from '@sveltejs/kit';
import type { Actions, PageServerLoad } from './$types';
import { getBook, getChapter, getChapters, getPublicQuestions } from '$lib/server/repository';
import db, { LOCAL_USER_ID } from '$lib/server/db';

function loadChapter(slug: string, chapterId: string) {
  const book = getBook(slug);
  if (!book) error(404, 'Книга не найдена');
  const chapter = getChapter(book.id, chapterId);
  if (!chapter) error(404, 'Глава не найдена');
  return { book, chapter };
}
export const load: PageServerLoad = ({ params }) => {
  const { book, chapter } = loadChapter(params.slug, params.chapterId);
  return { book, chapter, chapterCount: getChapters(book.id).length, questionCount: getPublicQuestions(book.id, 'chapter', chapter.id).length };
};
export const actions: Actions = {
  markRead: ({ params }) => {
    const { book, chapter } = loadChapter(params.slug, params.chapterId);
    db.prepare(`INSERT INTO user_progress (user_id, chapter_id, read_at, test_passed)
      VALUES (?, ?, ?, 0) ON CONFLICT(user_id, chapter_id) DO NOTHING`)
      .run(LOCAL_USER_ID, chapter.id, new Date().toISOString());
    redirect(303, `/books/${book.slug}/chapters/${chapter.id}/test`);
  }
};
