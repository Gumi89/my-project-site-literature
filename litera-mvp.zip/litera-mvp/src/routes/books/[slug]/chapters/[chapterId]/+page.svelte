<script lang="ts">
  import type { PageData } from './$types';
  import Icon from '$lib/components/Icon.svelte';
  import StatusBadge from '$lib/components/StatusBadge.svelte';
  export let data: PageData;
</script>
<svelte:head><title>{data.chapter.sourceLabel}: {data.chapter.title} — Литера</title></svelte:head>
<div class="shell page-wrap">
  <a class="back-link" href={`/books/${data.book.slug}`}><Icon name="arrow-left" size={15}/> {data.book.title}</a>
  <div class="chapter-layout">
    <article class="chapter-main">
      <div class="chapter-top"><div class="eyebrow">ЭТАП {String(data.chapter.position).padStart(2,'0')} / {String(data.chapterCount).padStart(2,'0')}</div><StatusBadge status={data.chapter.status}/></div>
      <div class="chapter-label">{data.chapter.sourceLabel}</div><h1>{data.chapter.title}</h1><p class="book-byline">{data.book.title} · {data.book.author}</p>
      <div class="content-card card"><div class="content-kicker"><Icon name="book" size={17}/><span>О ЧЁМ ЭТОТ ЭТАП</span></div><h2>Краткое содержание</h2><p>{data.chapter.summary}</p><a href={data.book.sourceUrl} target="_blank" rel="noopener noreferrer" class="inline-link">Читать полный текст <Icon name="arrow-up-right" size={14}/></a></div>
      <div class="quote-card"><div class="quote-mark">“</div><div><div class="content-kicker"><span>СТРОКИ ИЗ ПРОИЗВЕДЕНИЯ</span></div>{#each data.chapter.quotes as quote}<blockquote>«{quote.text}»</blockquote><cite>{quote.attribution}</cite>{/each}</div></div>
      <div class="finish-card card"><div><div class="finish-title">{data.chapter.readAt ? 'Готовы проверить себя?' : 'Прочитали этот этап?'}</div><p>{data.chapter.readAt ? 'Вы уже отметили чтение. Тест можно пройти ещё раз.' : 'Отметьте чтение и сразу переходите к мини-тесту.'}</p></div>
        {#if data.chapter.readAt}<a class="btn btn-primary" href={`/books/${data.book.slug}/chapters/${data.chapter.id}/test`}>{data.chapter.testPassed ? 'Пересдать мини-тест' : 'Пройти мини-тест'} <Icon name="arrow-right" size={16}/></a>
        {:else}<form method="POST" action="?/markRead"><button type="submit" class="btn btn-primary">Глава прочитана <Icon name="arrow-right" size={16}/></button></form>{/if}
      </div>
    </article>
    <aside class="chapter-aside"><div class="characters-card card"><div class="content-kicker"><Icon name="people" size={17}/><span>ДЕЙСТВУЮЩИЕ ЛИЦА</span></div><h2>Ключевые герои</h2><div class="characters">{#each data.chapter.characters as character}<span>{character}</span>{/each}</div></div><div class="reading-note"><Icon name="info" size={16}/><p>Краткое содержание — опора для повторения. Для подготовки важно прочитать само произведение.</p></div><div class="test-note"><div class="content-kicker"><span>ПОСЛЕ ЧТЕНИЯ</span></div><strong>Небольшая проверка</strong><p>{data.questionCount} {data.questionCount === 1 ? 'вопрос' : data.questionCount >= 2 && data.questionCount <= 4 ? 'вопроса' : 'вопросов'} по этапу. Если ошибётесь, покажем верный ответ и объяснение.</p></div></aside>
  </div>
</div>
<style>
.chapter-layout{display:grid;grid-template-columns:minmax(0,1fr) 295px;gap:25px}.chapter-top{display:flex;align-items:center;gap:15px}.chapter-label{font-size:12px;color:#88a192;margin-top:22px}.chapter-main h1{font:400 41px/1.1 var(--serif);letter-spacing:-1px;margin:7px 0}.book-byline{font-size:12px;color:#9aa99d;margin-bottom:25px}.content-card{padding:28px 30px}.content-kicker{display:flex;align-items:center;gap:8px;color:#88a793;font-size:9px;font-weight:800;letter-spacing:.12em}.content-card h2,.characters-card h2{font:400 23px var(--serif);margin:13px 0}.content-card>p{color:#5f7367;font-size:14px;line-height:1.85}.content-card .inline-link{margin-top:20px}.quote-card{display:flex;gap:19px;background:#eef4ed;border:1px solid #e4eee3;border-radius:12px;margin-top:15px;padding:24px 27px}.quote-mark{font:55px/.9 var(--serif);color:#a7c0ad}.quote-card blockquote{font:italic 20px/1.55 var(--serif);color:#4d6c59;margin:11px 0}.quote-card cite{font-style:normal;font-size:11px;color:#95aa99}.finish-card{padding:22px 25px;margin-top:15px;display:flex;justify-content:space-between;align-items:center;gap:20px}.finish-title{font:400 19px var(--serif)}.finish-card p{font-size:11px;color:#94a397;line-height:1.6;margin-top:6px}.finish-card .btn{white-space:nowrap}.chapter-aside{display:grid;align-content:start;gap:14px}.characters-card{padding:23px}.characters-card h2{font-size:20px}.characters{display:flex;gap:7px;flex-wrap:wrap;margin-top:16px}.characters span{padding:7px 9px;color:#6c8977;font-size:11px;background:#f0f5ef;border-radius:6px}.reading-note{display:flex;gap:9px;color:#9aa99d;font-size:11px;line-height:1.65;padding:5px}.reading-note :global(svg){flex:none;margin-top:1px}.test-note{padding:21px;background:#faf2e8;border:1px solid #f4e9da;border-radius:12px}.test-note .content-kicker{color:#c39c7b}.test-note strong{display:block;font:400 18px var(--serif);margin:10px 0 7px}.test-note p{color:#ab9988;font-size:11px;line-height:1.65}
@media(max-width:750px){.chapter-layout{grid-template-columns:1fr}.chapter-main h1{font-size:35px}.chapter-aside{grid-template-columns:1fr 1fr}.reading-note{grid-column:1/-1;grid-row:2}.content-card{padding:23px}.finish-card{align-items:stretch;flex-direction:column}.finish-card form,.finish-card .btn{width:100%}}
@media(max-width:450px){.chapter-aside{grid-template-columns:1fr}.reading-note{grid-column:auto;grid-row:auto}.quote-card{padding:20px}.chapter-main h1{font-size:31px}}
</style>
