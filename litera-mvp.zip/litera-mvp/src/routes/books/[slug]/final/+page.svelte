<script lang="ts">
  import type { ActionData, PageData } from './$types';
  import Icon from '$lib/components/Icon.svelte';
  import QuizForm from '$lib/components/QuizForm.svelte';
  import { plural } from '$lib/format';
  export let data: PageData;
  export let form: ActionData;
</script>
<svelte:head><title>Итоговый тест — {data.book.title} — Литера</title></svelte:head>
<div class="shell page-wrap"><div class="quiz-layout">
  <a class="back-link" href={`/books/${data.book.slug}`}><Icon name="arrow-left" size={15}/> Вернуться к книге</a>
  <header class="quiz-heading"><div class="eyebrow"><span class="eyebrow-dot"></span> ИТОГОВЫЙ ТЕСТ</div><h1>Книга прочитана.<br/>Закрепим главное.</h1><p>{data.book.title} · {data.book.author}</p><div class="quiz-meta"><span><Icon name="list" size={15}/> {data.questions.length} {plural(data.questions.length,'вопрос','вопроса','вопросов')}</span><span><Icon name="check" size={15}/> Для зачёта — от {data.passPercent}%</span></div></header>
  <QuizForm questions={data.questions} {form}/>
</div></div>
