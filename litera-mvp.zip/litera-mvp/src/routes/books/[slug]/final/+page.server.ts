import { error, fail, redirect } from '@sveltejs/kit';
import type { Actions, PageServerLoad } from './$types';
import { getBook, getPublicQuestions } from '$lib/server/repository';
import { PASS_PERCENT, submitQuiz } from '$lib/server/quiz';

function checkedBook(slug: string) {
  const book = getBook(slug);
  if (!book) error(404, 'Книга не найдена');
  // Recheck on POST as well as GET; a disabled button alone is not a guard.
  if (book.chapterCount === 0 || book.passedCount !== book.chapterCount) redirect(303, `/books/${book.slug}?locked=1`);
  return book;
}
export const load: PageServerLoad = ({ params }) => {
  const book = checkedBook(params.slug);
  const questions = getPublicQuestions(book.id, 'final', null);
  if (!questions.length) error(503, 'Итоговый тест пока не добавлен');
  return { book, questions, passPercent: PASS_PERCENT };
};
export const actions: Actions = {
  submit: async ({ params, request }) => {
    const book = checkedBook(params.slug);
    const result = submitQuiz(book.id, 'final', null, await request.formData());
    if (!result.ok) return fail(400, { message: result.message, values: result.values });
    redirect(303, `/attempts/${result.attemptId}`);
  }
};
