<script lang="ts">
  import { page } from '$app/stores';
  import Icon from '$lib/components/Icon.svelte';
  import '../app.css';
  $: isDashboard = $page.url.pathname.startsWith('/dashboard');
</script>
<svelte:head><meta name="description" content="Простой план чтения и проверка понимания произведений для подготовки к ЕГЭ по литературе." /></svelte:head>
<header class="site-header">
  <div class="header-inner shell">
    <a class="brand" href="/" aria-label="Литера — на главную"><span class="brand-mark">л<span>•</span></span><span>литера<span class="brand-period">.</span></span></a>
    <nav aria-label="Основная навигация">
      <a href="/" class:nav-active={!isDashboard} aria-current={!isDashboard ? 'page' : undefined}>План чтения</a>
      <a href="/dashboard" class:nav-active={isDashboard} aria-current={isDashboard ? 'page' : undefined}>Мой прогресс</a>
    </nav>
    <div class="header-note"><Icon name="book" size={16} /><span>ЕГЭ по литературе</span></div>
  </div>
</header>
<main><slot /></main>
<footer class="site-footer shell"><a class="footer-brand" href="/">литера<span>.</span></a><p>Небольшие шаги к большим книгам.</p><span>ПОДГОТОВКА К ЕГЭ</span></footer>
