// Integration smoke test against the production adapter-node build.
// It uses a temporary SQLite database and does not touch app.db.
import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createServer } from 'node:net';
import assert from 'node:assert/strict';
import Database from 'better-sqlite3';

const dir = mkdtempSync(join(tmpdir(), 'literatura-smoke-'));
const dbPath = join(dir, 'test.db');
const socket = createServer();
await new Promise((resolve) => socket.listen(0, '127.0.0.1', resolve));
const port = socket.address().port;
await new Promise((resolve) => socket.close(resolve));
const base = `http://127.0.0.1:${port}`;
const child = spawn(process.execPath, ['build'], {
  env: { ...process.env, HOST: '127.0.0.1', PORT: String(port), ORIGIN: base, DATABASE_PATH: dbPath },
  stdio: ['ignore', 'pipe', 'pipe']
});
let logs = '';
child.stdout.on('data', (chunk) => { logs += chunk; });
child.stderr.on('data', (chunk) => { logs += chunk; });
let db;
try {
  await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error(`Server did not start: ${logs}`)), 15000);
    child.stdout.on('data', (chunk) => {
      if (String(chunk).includes('Listening on')) { clearTimeout(timeout); resolve(); }
    });
    child.once('exit', (code) => { clearTimeout(timeout); reject(new Error(`Server exited: ${code} ${logs}`)); });
  });
  async function request(path, method = 'GET', values) {
    const headers = { Accept: 'text/html', Origin: base };
    const options = { method, headers, redirect: 'manual' };
    if (method === 'POST') { headers['Content-Type'] = 'application/x-www-form-urlencoded'; options.body = new URLSearchParams(values ?? []); }
    const response = await fetch(`${base}${path}`, options);
    return { status: response.status, location: response.headers.get('location'), html: await response.text() };
  }
  const home = await request('/');
  assert.equal(home.status, 200);
  assert.match(home.html, /Прочитано 0 из 2 книг/);
  db = new Database(dbPath, { readonly: true });
  const book = db.prepare("SELECT id, slug FROM books WHERE slug = 'kapitanskaya-dochka'").get();
  const chapters = db.prepare('SELECT id FROM chapters WHERE book_id = ? ORDER BY position').all(book.id);
  assert.equal(chapters.length, 2);
  const chapterUrl = (id) => `/books/${book.slug}/chapters/${id}`;
  const finalUrl = `/books/${book.slug}/final`;
  assert.equal((await request(`${chapterUrl(chapters[0].id)}/test`)).status, 303, 'Unread quiz must redirect');
  assert.equal((await request(finalUrl)).status, 303, 'Final must be locked before mini-tests');
  assert.equal((await request(`${finalUrl}?/submit`, 'POST')).status, 303, 'POST must also enforce the gate');

  function questionsFor(kind, chapterId) {
    return db.prepare(`SELECT id, correct_option, options, explanation, reference_chapter_id FROM questions
      WHERE book_id = ? AND kind = ? AND chapter_id IS ? ORDER BY position`).all(book.id, kind, chapterId);
  }
  function answers(questions, correctCount) {
    return questions.map((q, i) => [`q_${q.id}`, String(i < correctCount ? q.correct_option : (q.correct_option + 1) % JSON.parse(q.options).length)]);
  }
  async function mark(id) {
    const result = await request(`${chapterUrl(id)}?/markRead`, 'POST');
    assert.equal(result.status, 303);
    assert.equal(result.location, `${chapterUrl(id)}/test`);
  }
  async function submit(path, params) { return request(`${path}?/submit`, 'POST', params); }
  const first = chapters[0].id;
  await mark(first);
  const qs = questionsFor('chapter', first);
  assert.equal(qs.length, 4);
  const quiz = await request(`${chapterUrl(first)}/test`);
  assert.equal(quiz.status, 200);
  assert.ok(!quiz.html.includes(qs[0].explanation), 'Explanations must not leak before submitting');
  assert.equal((await submit(`${chapterUrl(first)}/test`, answers(qs, 4).slice(0, 3))).status, 400, 'Missing answer');
  assert.equal((await submit(`${chapterUrl(first)}/test`, [...answers(qs, 4), [`q_${qs[0].id}`, '1']])).status, 400, 'Duplicate answer');
  assert.equal((await submit(`${chapterUrl(first)}/test`, answers(qs, 4).map((x, i) => i ? x : [x[0], '99']))).status, 400, 'Out-of-range answer');
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM test_attempts').get().n, 0);

  const failed = await submit(`${chapterUrl(first)}/test`, answers(qs, 2));
  assert.equal(failed.status, 303);
  const review = await request(failed.location);
  assert.equal(review.status, 200);
  assert.match(review.html, /Есть что повторить/);
  assert.ok(review.html.includes(qs[2].explanation), 'Explanation must appear on the results page');
  assert.ok(review.html.includes(JSON.parse(qs[2].options)[qs[2].correct_option]), 'Correct answer shown');
  assert.ok(review.html.includes(chapterUrl(qs[2].reference_chapter_id)), 'A link to the relevant chapter is shown');
  assert.equal(db.prepare('SELECT test_passed FROM user_progress WHERE chapter_id = ?').get(first).test_passed, 0);
  const weakDashboard = await request('/dashboard');
  assert.ok(weakDashboard.html.includes('50%'), 'Average uses latest test attempts');
  assert.ok(weakDashboard.html.includes('Темы для внимания'), 'Weak topics are shown');

  const success = await submit(`${chapterUrl(first)}/test`, answers(qs, 4));
  assert.equal(success.status, 303);
  assert.match((await request(success.location)).html, /Тест пройден/);
  assert.equal(db.prepare('SELECT test_passed FROM user_progress WHERE chapter_id = ?').get(first).test_passed, 1);
  assert.ok((await request('/dashboard')).html.includes('100%'), 'Retake replaces earlier score in average');
  await mark(first); // idempotent; must not reset success
  await submit(`${chapterUrl(first)}/test`, answers(qs, 0)); // failure must not undo an earlier pass
  assert.equal(db.prepare('SELECT test_passed FROM user_progress WHERE chapter_id = ?').get(first).test_passed, 1);
  await submit(`${chapterUrl(first)}/test`, answers(qs, 4));

  for (const chapter of chapters.slice(1)) {
    await mark(chapter.id);
    assert.equal((await submit(`${chapterUrl(chapter.id)}/test`, answers(questionsFor('chapter', chapter.id), 4))).status, 303);
  }
  assert.equal((await request(finalUrl)).status, 200, 'Final unlocks when every mini-test has passed');
  const finalQuestions = questionsFor('final', null);
  assert.equal(finalQuestions.length, 10);
  const finalFailed = await submit(finalUrl, answers(finalQuestions, 6));
  assert.match((await request(finalFailed.location)).html, /Есть что повторить/);
  assert.match((await request('/')).html, /Прочитано 0 из 2 книг/);
  const finalPassed = await submit(finalUrl, answers(finalQuestions, 7));
  const finalReview = await request(finalPassed.location);
  assert.match(finalReview.html, /Тест пройден/);
  assert.match((await request('/')).html, /Прочитано 1 из 2 книг/);
  await submit(finalUrl, answers(finalQuestions, 0));
  assert.match((await request('/')).html, /Прочитано 1 из 2 книг/, 'A failed retry must not uncomplete the book');
  assert.equal((await request(`/books/groza/chapters/${first}`)).status, 404, 'Chapter must belong to this book');
  assert.equal((await request('/attempts/99999999')).status, 404);
  assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(), []);
  console.log('✓ Production SSR, reading, validation, failed/successful retries, explanations, final gate, progress and foreign keys');
} finally {
  if (db) db.close();
  child.kill('SIGTERM');
  await new Promise((resolve) => child.once('exit', resolve));
  rmSync(dir, { recursive: true, force: true });
}
